; Auto-generated. Do not edit!


(cl:in-package rt_logger-msg)


;//! \htmlinclude LoggerNumeric.msg.html

(cl:defclass <LoggerNumeric> (roslisp-msg-protocol:ros-message)
  ((name
    :reader name
    :initarg :name
    :type std_msgs-msg:String
    :initform (cl:make-instance 'std_msgs-msg:String))
   (array
    :reader array
    :initarg :array
    :type std_msgs-msg:Float64MultiArray
    :initform (cl:make-instance 'std_msgs-msg:Float64MultiArray)))
)

(cl:defclass LoggerNumeric (<LoggerNumeric>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <LoggerNumeric>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'LoggerNumeric)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name rt_logger-msg:<LoggerNumeric> is deprecated: use rt_logger-msg:LoggerNumeric instead.")))

(cl:ensure-generic-function 'name-val :lambda-list '(m))
(cl:defmethod name-val ((m <LoggerNumeric>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader rt_logger-msg:name-val is deprecated.  Use rt_logger-msg:name instead.")
  (name m))

(cl:ensure-generic-function 'array-val :lambda-list '(m))
(cl:defmethod array-val ((m <LoggerNumeric>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader rt_logger-msg:array-val is deprecated.  Use rt_logger-msg:array instead.")
  (array m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <LoggerNumeric>) ostream)
  "Serializes a message object of type '<LoggerNumeric>"
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'name) ostream)
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'array) ostream)
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <LoggerNumeric>) istream)
  "Deserializes a message object of type '<LoggerNumeric>"
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'name) istream)
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'array) istream)
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<LoggerNumeric>)))
  "Returns string type for a message object of type '<LoggerNumeric>"
  "rt_logger/LoggerNumeric")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'LoggerNumeric)))
  "Returns string type for a message object of type 'LoggerNumeric"
  "rt_logger/LoggerNumeric")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<LoggerNumeric>)))
  "Returns md5sum for a message object of type '<LoggerNumeric>"
  "f23b3225a6fd33f53df40404120a5f86")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'LoggerNumeric)))
  "Returns md5sum for a message object of type 'LoggerNumeric"
  "f23b3225a6fd33f53df40404120a5f86")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<LoggerNumeric>)))
  "Returns full string definition for message of type '<LoggerNumeric>"
  (cl:format cl:nil "std_msgs/String name~%std_msgs/Float64MultiArray array~%~%================================================================================~%MSG: std_msgs/String~%string data~%~%================================================================================~%MSG: std_msgs/Float64MultiArray~%# Please look at the MultiArrayLayout message definition for~%# documentation on all multiarrays.~%~%MultiArrayLayout  layout        # specification of data layout~%float64[]         data          # array of data~%~%~%================================================================================~%MSG: std_msgs/MultiArrayLayout~%# The multiarray declares a generic multi-dimensional array of a~%# particular data type.  Dimensions are ordered from outer most~%# to inner most.~%~%MultiArrayDimension[] dim # Array of dimension properties~%uint32 data_offset        # padding elements at front of data~%~%# Accessors should ALWAYS be written in terms of dimension stride~%# and specified outer-most dimension first.~%# ~%# multiarray(i,j,k) = data[data_offset + dim_stride[1]*i + dim_stride[2]*j + k]~%#~%# A standard, 3-channel 640x480 image with interleaved color channels~%# would be specified as:~%#~%# dim[0].label  = \"height\"~%# dim[0].size   = 480~%# dim[0].stride = 3*640*480 = 921600  (note dim[0] stride is just size of image)~%# dim[1].label  = \"width\"~%# dim[1].size   = 640~%# dim[1].stride = 3*640 = 1920~%# dim[2].label  = \"channel\"~%# dim[2].size   = 3~%# dim[2].stride = 3~%#~%# multiarray(i,j,k) refers to the ith row, jth column, and kth channel.~%~%================================================================================~%MSG: std_msgs/MultiArrayDimension~%string label   # label of given dimension~%uint32 size    # size of given dimension (in type units)~%uint32 stride  # stride of given dimension~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'LoggerNumeric)))
  "Returns full string definition for message of type 'LoggerNumeric"
  (cl:format cl:nil "std_msgs/String name~%std_msgs/Float64MultiArray array~%~%================================================================================~%MSG: std_msgs/String~%string data~%~%================================================================================~%MSG: std_msgs/Float64MultiArray~%# Please look at the MultiArrayLayout message definition for~%# documentation on all multiarrays.~%~%MultiArrayLayout  layout        # specification of data layout~%float64[]         data          # array of data~%~%~%================================================================================~%MSG: std_msgs/MultiArrayLayout~%# The multiarray declares a generic multi-dimensional array of a~%# particular data type.  Dimensions are ordered from outer most~%# to inner most.~%~%MultiArrayDimension[] dim # Array of dimension properties~%uint32 data_offset        # padding elements at front of data~%~%# Accessors should ALWAYS be written in terms of dimension stride~%# and specified outer-most dimension first.~%# ~%# multiarray(i,j,k) = data[data_offset + dim_stride[1]*i + dim_stride[2]*j + k]~%#~%# A standard, 3-channel 640x480 image with interleaved color channels~%# would be specified as:~%#~%# dim[0].label  = \"height\"~%# dim[0].size   = 480~%# dim[0].stride = 3*640*480 = 921600  (note dim[0] stride is just size of image)~%# dim[1].label  = \"width\"~%# dim[1].size   = 640~%# dim[1].stride = 3*640 = 1920~%# dim[2].label  = \"channel\"~%# dim[2].size   = 3~%# dim[2].stride = 3~%#~%# multiarray(i,j,k) refers to the ith row, jth column, and kth channel.~%~%================================================================================~%MSG: std_msgs/MultiArrayDimension~%string label   # label of given dimension~%uint32 size    # size of given dimension (in type units)~%uint32 stride  # stride of given dimension~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <LoggerNumeric>))
  (cl:+ 0
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'name))
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'array))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <LoggerNumeric>))
  "Converts a ROS message object to a list"
  (cl:list 'LoggerNumeric
    (cl:cons ':name (name msg))
    (cl:cons ':array (array msg))
))
