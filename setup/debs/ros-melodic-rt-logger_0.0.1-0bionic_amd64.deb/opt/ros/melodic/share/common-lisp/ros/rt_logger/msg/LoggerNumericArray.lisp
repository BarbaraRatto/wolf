; Auto-generated. Do not edit!


(cl:in-package rt_logger-msg)


;//! \htmlinclude LoggerNumericArray.msg.html

(cl:defclass <LoggerNumericArray> (roslisp-msg-protocol:ros-message)
  ((time
    :reader time
    :initarg :time
    :type std_msgs-msg:Time
    :initform (cl:make-instance 'std_msgs-msg:Time))
   (array
    :reader array
    :initarg :array
    :type (cl:vector rt_logger-msg:LoggerNumeric)
   :initform (cl:make-array 0 :element-type 'rt_logger-msg:LoggerNumeric :initial-element (cl:make-instance 'rt_logger-msg:LoggerNumeric))))
)

(cl:defclass LoggerNumericArray (<LoggerNumericArray>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <LoggerNumericArray>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'LoggerNumericArray)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name rt_logger-msg:<LoggerNumericArray> is deprecated: use rt_logger-msg:LoggerNumericArray instead.")))

(cl:ensure-generic-function 'time-val :lambda-list '(m))
(cl:defmethod time-val ((m <LoggerNumericArray>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader rt_logger-msg:time-val is deprecated.  Use rt_logger-msg:time instead.")
  (time m))

(cl:ensure-generic-function 'array-val :lambda-list '(m))
(cl:defmethod array-val ((m <LoggerNumericArray>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader rt_logger-msg:array-val is deprecated.  Use rt_logger-msg:array instead.")
  (array m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <LoggerNumericArray>) ostream)
  "Serializes a message object of type '<LoggerNumericArray>"
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'time) ostream)
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'array))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (roslisp-msg-protocol:serialize ele ostream))
   (cl:slot-value msg 'array))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <LoggerNumericArray>) istream)
  "Deserializes a message object of type '<LoggerNumericArray>"
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'time) istream)
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'array) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'array)))
    (cl:dotimes (i __ros_arr_len)
    (cl:setf (cl:aref vals i) (cl:make-instance 'rt_logger-msg:LoggerNumeric))
  (roslisp-msg-protocol:deserialize (cl:aref vals i) istream))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<LoggerNumericArray>)))
  "Returns string type for a message object of type '<LoggerNumericArray>"
  "rt_logger/LoggerNumericArray")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'LoggerNumericArray)))
  "Returns string type for a message object of type 'LoggerNumericArray"
  "rt_logger/LoggerNumericArray")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<LoggerNumericArray>)))
  "Returns md5sum for a message object of type '<LoggerNumericArray>"
  "b85aac77b4d19409ef377444a6069ae1")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'LoggerNumericArray)))
  "Returns md5sum for a message object of type 'LoggerNumericArray"
  "b85aac77b4d19409ef377444a6069ae1")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<LoggerNumericArray>)))
  "Returns full string definition for message of type '<LoggerNumericArray>"
  (cl:format cl:nil "std_msgs/Time time~%rt_logger/LoggerNumeric[] array~%~%================================================================================~%MSG: std_msgs/Time~%time data~%~%================================================================================~%MSG: rt_logger/LoggerNumeric~%std_msgs/String name~%std_msgs/Float64MultiArray array~%~%================================================================================~%MSG: std_msgs/String~%string data~%~%================================================================================~%MSG: std_msgs/Float64MultiArray~%# Please look at the MultiArrayLayout message definition for~%# documentation on all multiarrays.~%~%MultiArrayLayout  layout        # specification of data layout~%float64[]         data          # array of data~%~%~%================================================================================~%MSG: std_msgs/MultiArrayLayout~%# The multiarray declares a generic multi-dimensional array of a~%# particular data type.  Dimensions are ordered from outer most~%# to inner most.~%~%MultiArrayDimension[] dim # Array of dimension properties~%uint32 data_offset        # padding elements at front of data~%~%# Accessors should ALWAYS be written in terms of dimension stride~%# and specified outer-most dimension first.~%# ~%# multiarray(i,j,k) = data[data_offset + dim_stride[1]*i + dim_stride[2]*j + k]~%#~%# A standard, 3-channel 640x480 image with interleaved color channels~%# would be specified as:~%#~%# dim[0].label  = \"height\"~%# dim[0].size   = 480~%# dim[0].stride = 3*640*480 = 921600  (note dim[0] stride is just size of image)~%# dim[1].label  = \"width\"~%# dim[1].size   = 640~%# dim[1].stride = 3*640 = 1920~%# dim[2].label  = \"channel\"~%# dim[2].size   = 3~%# dim[2].stride = 3~%#~%# multiarray(i,j,k) refers to the ith row, jth column, and kth channel.~%~%================================================================================~%MSG: std_msgs/MultiArrayDimension~%string label   # label of given dimension~%uint32 size    # size of given dimension (in type units)~%uint32 stride  # stride of given dimension~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'LoggerNumericArray)))
  "Returns full string definition for message of type 'LoggerNumericArray"
  (cl:format cl:nil "std_msgs/Time time~%rt_logger/LoggerNumeric[] array~%~%================================================================================~%MSG: std_msgs/Time~%time data~%~%================================================================================~%MSG: rt_logger/LoggerNumeric~%std_msgs/String name~%std_msgs/Float64MultiArray array~%~%================================================================================~%MSG: std_msgs/String~%string data~%~%================================================================================~%MSG: std_msgs/Float64MultiArray~%# Please look at the MultiArrayLayout message definition for~%# documentation on all multiarrays.~%~%MultiArrayLayout  layout        # specification of data layout~%float64[]         data          # array of data~%~%~%================================================================================~%MSG: std_msgs/MultiArrayLayout~%# The multiarray declares a generic multi-dimensional array of a~%# particular data type.  Dimensions are ordered from outer most~%# to inner most.~%~%MultiArrayDimension[] dim # Array of dimension properties~%uint32 data_offset        # padding elements at front of data~%~%# Accessors should ALWAYS be written in terms of dimension stride~%# and specified outer-most dimension first.~%# ~%# multiarray(i,j,k) = data[data_offset + dim_stride[1]*i + dim_stride[2]*j + k]~%#~%# A standard, 3-channel 640x480 image with interleaved color channels~%# would be specified as:~%#~%# dim[0].label  = \"height\"~%# dim[0].size   = 480~%# dim[0].stride = 3*640*480 = 921600  (note dim[0] stride is just size of image)~%# dim[1].label  = \"width\"~%# dim[1].size   = 640~%# dim[1].stride = 3*640 = 1920~%# dim[2].label  = \"channel\"~%# dim[2].size   = 3~%# dim[2].stride = 3~%#~%# multiarray(i,j,k) refers to the ith row, jth column, and kth channel.~%~%================================================================================~%MSG: std_msgs/MultiArrayDimension~%string label   # label of given dimension~%uint32 size    # size of given dimension (in type units)~%uint32 stride  # stride of given dimension~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <LoggerNumericArray>))
  (cl:+ 0
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'time))
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'array) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ (roslisp-msg-protocol:serialization-length ele))))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <LoggerNumericArray>))
  "Converts a ROS message object to a list"
  (cl:list 'LoggerNumericArray
    (cl:cons ':time (time msg))
    (cl:cons ':array (array msg))
))
