(cl:defpackage rt_logger-msg
  (:use )
  (:export
   "<LOGGERNUMERIC>"
   "LOGGERNUMERIC"
   "<LOGGERNUMERICARRAY>"
   "LOGGERNUMERICARRAY"
  ))

