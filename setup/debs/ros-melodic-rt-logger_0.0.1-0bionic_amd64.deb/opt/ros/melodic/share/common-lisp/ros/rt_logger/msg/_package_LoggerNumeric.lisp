(cl:in-package rt_logger-msg)
(cl:export '(NAME-VAL
          NAME
          ARRAY-VAL
          ARRAY
))