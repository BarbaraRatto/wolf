(cl:in-package rt_logger-msg)
(cl:export '(TIME-VAL
          TIME
          ARRAY-VAL
          ARRAY
))