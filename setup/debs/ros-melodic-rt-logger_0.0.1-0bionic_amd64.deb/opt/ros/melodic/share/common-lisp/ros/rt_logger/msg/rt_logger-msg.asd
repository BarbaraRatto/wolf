
(cl:in-package :asdf)

(defsystem "rt_logger-msg"
  :depends-on (:roslisp-msg-protocol :roslisp-utils :std_msgs-msg
)
  :components ((:file "_package")
    (:file "LoggerNumeric" :depends-on ("_package_LoggerNumeric"))
    (:file "_package_LoggerNumeric" :depends-on ("_package"))
    (:file "LoggerNumericArray" :depends-on ("_package_LoggerNumericArray"))
    (:file "_package_LoggerNumericArray" :depends-on ("_package"))
  ))