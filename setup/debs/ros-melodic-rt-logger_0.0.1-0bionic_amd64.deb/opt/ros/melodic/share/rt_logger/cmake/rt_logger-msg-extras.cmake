set(rt_logger_MESSAGE_FILES "msg/LoggerNumeric.msg;msg/LoggerNumericArray.msg")
set(rt_logger_SERVICE_FILES "")
