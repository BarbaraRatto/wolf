# generated from genmsg/cmake/pkg-msg-paths.cmake.installspace.in

_prepend_path("${rt_logger_DIR}/.." "msg" rt_logger_MSG_INCLUDE_DIRS UNIQUE)
set(rt_logger_MSG_DEPENDENCIES std_msgs)
