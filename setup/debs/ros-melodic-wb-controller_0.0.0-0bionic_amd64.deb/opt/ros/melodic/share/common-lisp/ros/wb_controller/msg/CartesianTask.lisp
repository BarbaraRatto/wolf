; Auto-generated. Do not edit!


(cl:in-package wb_controller-msg)


;//! \htmlinclude CartesianTask.msg.html

(cl:defclass <CartesianTask> (roslisp-msg-protocol:ros-message)
  ((header
    :reader header
    :initarg :header
    :type std_msgs-msg:Header
    :initform (cl:make-instance 'std_msgs-msg:Header))
   (pose_actual
    :reader pose_actual
    :initarg :pose_actual
    :type geometry_msgs-msg:Pose
    :initform (cl:make-instance 'geometry_msgs-msg:Pose))
   (pose_reference
    :reader pose_reference
    :initarg :pose_reference
    :type geometry_msgs-msg:Pose
    :initform (cl:make-instance 'geometry_msgs-msg:Pose))
   (twist_actual
    :reader twist_actual
    :initarg :twist_actual
    :type geometry_msgs-msg:Twist
    :initform (cl:make-instance 'geometry_msgs-msg:Twist))
   (twist_reference
    :reader twist_reference
    :initarg :twist_reference
    :type geometry_msgs-msg:Twist
    :initform (cl:make-instance 'geometry_msgs-msg:Twist)))
)

(cl:defclass CartesianTask (<CartesianTask>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <CartesianTask>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'CartesianTask)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name wb_controller-msg:<CartesianTask> is deprecated: use wb_controller-msg:CartesianTask instead.")))

(cl:ensure-generic-function 'header-val :lambda-list '(m))
(cl:defmethod header-val ((m <CartesianTask>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader wb_controller-msg:header-val is deprecated.  Use wb_controller-msg:header instead.")
  (header m))

(cl:ensure-generic-function 'pose_actual-val :lambda-list '(m))
(cl:defmethod pose_actual-val ((m <CartesianTask>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader wb_controller-msg:pose_actual-val is deprecated.  Use wb_controller-msg:pose_actual instead.")
  (pose_actual m))

(cl:ensure-generic-function 'pose_reference-val :lambda-list '(m))
(cl:defmethod pose_reference-val ((m <CartesianTask>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader wb_controller-msg:pose_reference-val is deprecated.  Use wb_controller-msg:pose_reference instead.")
  (pose_reference m))

(cl:ensure-generic-function 'twist_actual-val :lambda-list '(m))
(cl:defmethod twist_actual-val ((m <CartesianTask>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader wb_controller-msg:twist_actual-val is deprecated.  Use wb_controller-msg:twist_actual instead.")
  (twist_actual m))

(cl:ensure-generic-function 'twist_reference-val :lambda-list '(m))
(cl:defmethod twist_reference-val ((m <CartesianTask>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader wb_controller-msg:twist_reference-val is deprecated.  Use wb_controller-msg:twist_reference instead.")
  (twist_reference m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <CartesianTask>) ostream)
  "Serializes a message object of type '<CartesianTask>"
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'header) ostream)
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'pose_actual) ostream)
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'pose_reference) ostream)
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'twist_actual) ostream)
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'twist_reference) ostream)
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <CartesianTask>) istream)
  "Deserializes a message object of type '<CartesianTask>"
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'header) istream)
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'pose_actual) istream)
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'pose_reference) istream)
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'twist_actual) istream)
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'twist_reference) istream)
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<CartesianTask>)))
  "Returns string type for a message object of type '<CartesianTask>"
  "wb_controller/CartesianTask")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'CartesianTask)))
  "Returns string type for a message object of type 'CartesianTask"
  "wb_controller/CartesianTask")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<CartesianTask>)))
  "Returns md5sum for a message object of type '<CartesianTask>"
  "468dd65b3b1777f53457b3eb845bb918")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'CartesianTask)))
  "Returns md5sum for a message object of type 'CartesianTask"
  "468dd65b3b1777f53457b3eb845bb918")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<CartesianTask>)))
  "Returns full string definition for message of type '<CartesianTask>"
  (cl:format cl:nil "std_msgs/Header header~%geometry_msgs/Pose pose_actual~%geometry_msgs/Pose pose_reference~%geometry_msgs/Twist twist_actual~%geometry_msgs/Twist twist_reference~%~%================================================================================~%MSG: std_msgs/Header~%# Standard metadata for higher-level stamped data types.~%# This is generally used to communicate timestamped data ~%# in a particular coordinate frame.~%# ~%# sequence ID: consecutively increasing ID ~%uint32 seq~%#Two-integer timestamp that is expressed as:~%# * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')~%# * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')~%# time-handling sugar is provided by the client library~%time stamp~%#Frame this data is associated with~%string frame_id~%~%================================================================================~%MSG: geometry_msgs/Pose~%# A representation of pose in free space, composed of position and orientation. ~%Point position~%Quaternion orientation~%~%================================================================================~%MSG: geometry_msgs/Point~%# This contains the position of a point in free space~%float64 x~%float64 y~%float64 z~%~%================================================================================~%MSG: geometry_msgs/Quaternion~%# This represents an orientation in free space in quaternion form.~%~%float64 x~%float64 y~%float64 z~%float64 w~%~%================================================================================~%MSG: geometry_msgs/Twist~%# This expresses velocity in free space broken into its linear and angular parts.~%Vector3  linear~%Vector3  angular~%~%================================================================================~%MSG: geometry_msgs/Vector3~%# This represents a vector in free space. ~%# It is only meant to represent a direction. Therefore, it does not~%# make sense to apply a translation to it (e.g., when applying a ~%# generic rigid transformation to a Vector3, tf2 will only apply the~%# rotation). If you want your data to be translatable too, use the~%# geometry_msgs/Point message instead.~%~%float64 x~%float64 y~%float64 z~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'CartesianTask)))
  "Returns full string definition for message of type 'CartesianTask"
  (cl:format cl:nil "std_msgs/Header header~%geometry_msgs/Pose pose_actual~%geometry_msgs/Pose pose_reference~%geometry_msgs/Twist twist_actual~%geometry_msgs/Twist twist_reference~%~%================================================================================~%MSG: std_msgs/Header~%# Standard metadata for higher-level stamped data types.~%# This is generally used to communicate timestamped data ~%# in a particular coordinate frame.~%# ~%# sequence ID: consecutively increasing ID ~%uint32 seq~%#Two-integer timestamp that is expressed as:~%# * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')~%# * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')~%# time-handling sugar is provided by the client library~%time stamp~%#Frame this data is associated with~%string frame_id~%~%================================================================================~%MSG: geometry_msgs/Pose~%# A representation of pose in free space, composed of position and orientation. ~%Point position~%Quaternion orientation~%~%================================================================================~%MSG: geometry_msgs/Point~%# This contains the position of a point in free space~%float64 x~%float64 y~%float64 z~%~%================================================================================~%MSG: geometry_msgs/Quaternion~%# This represents an orientation in free space in quaternion form.~%~%float64 x~%float64 y~%float64 z~%float64 w~%~%================================================================================~%MSG: geometry_msgs/Twist~%# This expresses velocity in free space broken into its linear and angular parts.~%Vector3  linear~%Vector3  angular~%~%================================================================================~%MSG: geometry_msgs/Vector3~%# This represents a vector in free space. ~%# It is only meant to represent a direction. Therefore, it does not~%# make sense to apply a translation to it (e.g., when applying a ~%# generic rigid transformation to a Vector3, tf2 will only apply the~%# rotation). If you want your data to be translatable too, use the~%# geometry_msgs/Point message instead.~%~%float64 x~%float64 y~%float64 z~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <CartesianTask>))
  (cl:+ 0
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'header))
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'pose_actual))
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'pose_reference))
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'twist_actual))
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'twist_reference))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <CartesianTask>))
  "Converts a ROS message object to a list"
  (cl:list 'CartesianTask
    (cl:cons ':header (header msg))
    (cl:cons ':pose_actual (pose_actual msg))
    (cl:cons ':pose_reference (pose_reference msg))
    (cl:cons ':twist_actual (twist_actual msg))
    (cl:cons ':twist_reference (twist_reference msg))
))
