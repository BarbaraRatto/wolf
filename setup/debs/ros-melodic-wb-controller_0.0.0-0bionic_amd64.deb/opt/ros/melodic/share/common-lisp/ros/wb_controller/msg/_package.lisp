(cl:defpackage wb_controller-msg
  (:use )
  (:export
   "<CARTESIANTASK>"
   "CARTESIANTASK"
   "<CONTACTFORCES>"
   "CONTACTFORCES"
   "<JOINTSTASK>"
   "JOINTSTASK"
  ))

