(cl:in-package wb_controller-msg)
(cl:export '(HEADER-VAL
          HEADER
          POSE_ACTUAL-VAL
          POSE_ACTUAL
          POSE_REFERENCE-VAL
          POSE_REFERENCE
          TWIST_ACTUAL-VAL
          TWIST_ACTUAL
          TWIST_REFERENCE-VAL
          TWIST_REFERENCE
))