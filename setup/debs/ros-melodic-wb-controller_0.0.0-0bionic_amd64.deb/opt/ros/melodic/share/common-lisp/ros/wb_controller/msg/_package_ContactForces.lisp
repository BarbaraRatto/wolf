(cl:in-package wb_controller-msg)
(cl:export '(HEADER-VAL
          HEADER
          NAME-VAL
          NAME
          CONTACT-VAL
          CONTACT
          CONTACT_POSITIONS-VAL
          CONTACT_POSITIONS
          DES_CONTACT_FORCES-VAL
          DES_CONTACT_FORCES
          CONTACT_FORCES-VAL
          CONTACT_FORCES
))