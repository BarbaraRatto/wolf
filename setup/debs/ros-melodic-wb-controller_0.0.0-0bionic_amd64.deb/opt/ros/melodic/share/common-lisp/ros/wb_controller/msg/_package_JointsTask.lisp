(cl:in-package wb_controller-msg)
(cl:export '(HEADER-VAL
          HEADER
          NAME-VAL
          NAME
          POSITION_ACTUAL-VAL
          POSITION_ACTUAL
          POSITION_REFERENCE-VAL
          POSITION_REFERENCE
          VELOCITY_ACTUAL-VAL
          VELOCITY_ACTUAL
          VELOCITY_REFERENCE-VAL
          VELOCITY_REFERENCE
          POSITION_ERROR-VAL
          POSITION_ERROR
          VELOCITY_ERROR-VAL
          VELOCITY_ERROR
))