
(cl:in-package :asdf)

(defsystem "wb_controller-msg"
  :depends-on (:roslisp-msg-protocol :roslisp-utils :geometry_msgs-msg
               :std_msgs-msg
)
  :components ((:file "_package")
    (:file "CartesianTask" :depends-on ("_package_CartesianTask"))
    (:file "_package_CartesianTask" :depends-on ("_package"))
    (:file "ContactForces" :depends-on ("_package_ContactForces"))
    (:file "_package_ContactForces" :depends-on ("_package"))
    (:file "JointsTask" :depends-on ("_package_JointsTask"))
    (:file "_package_JointsTask" :depends-on ("_package"))
  ))