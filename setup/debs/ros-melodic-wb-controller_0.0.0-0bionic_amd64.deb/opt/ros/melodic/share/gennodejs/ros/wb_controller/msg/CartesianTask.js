// Auto-generated. Do not edit!

// (in-package wb_controller.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let geometry_msgs = _finder('geometry_msgs');
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class CartesianTask {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.pose_actual = null;
      this.pose_reference = null;
      this.twist_actual = null;
      this.twist_reference = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('pose_actual')) {
        this.pose_actual = initObj.pose_actual
      }
      else {
        this.pose_actual = new geometry_msgs.msg.Pose();
      }
      if (initObj.hasOwnProperty('pose_reference')) {
        this.pose_reference = initObj.pose_reference
      }
      else {
        this.pose_reference = new geometry_msgs.msg.Pose();
      }
      if (initObj.hasOwnProperty('twist_actual')) {
        this.twist_actual = initObj.twist_actual
      }
      else {
        this.twist_actual = new geometry_msgs.msg.Twist();
      }
      if (initObj.hasOwnProperty('twist_reference')) {
        this.twist_reference = initObj.twist_reference
      }
      else {
        this.twist_reference = new geometry_msgs.msg.Twist();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type CartesianTask
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [pose_actual]
    bufferOffset = geometry_msgs.msg.Pose.serialize(obj.pose_actual, buffer, bufferOffset);
    // Serialize message field [pose_reference]
    bufferOffset = geometry_msgs.msg.Pose.serialize(obj.pose_reference, buffer, bufferOffset);
    // Serialize message field [twist_actual]
    bufferOffset = geometry_msgs.msg.Twist.serialize(obj.twist_actual, buffer, bufferOffset);
    // Serialize message field [twist_reference]
    bufferOffset = geometry_msgs.msg.Twist.serialize(obj.twist_reference, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type CartesianTask
    let len;
    let data = new CartesianTask(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [pose_actual]
    data.pose_actual = geometry_msgs.msg.Pose.deserialize(buffer, bufferOffset);
    // Deserialize message field [pose_reference]
    data.pose_reference = geometry_msgs.msg.Pose.deserialize(buffer, bufferOffset);
    // Deserialize message field [twist_actual]
    data.twist_actual = geometry_msgs.msg.Twist.deserialize(buffer, bufferOffset);
    // Deserialize message field [twist_reference]
    data.twist_reference = geometry_msgs.msg.Twist.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    return length + 208;
  }

  static datatype() {
    // Returns string type for a message object
    return 'wb_controller/CartesianTask';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '468dd65b3b1777f53457b3eb845bb918';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    std_msgs/Header header
    geometry_msgs/Pose pose_actual
    geometry_msgs/Pose pose_reference
    geometry_msgs/Twist twist_actual
    geometry_msgs/Twist twist_reference
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    string frame_id
    
    ================================================================================
    MSG: geometry_msgs/Pose
    # A representation of pose in free space, composed of position and orientation. 
    Point position
    Quaternion orientation
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    ================================================================================
    MSG: geometry_msgs/Twist
    # This expresses velocity in free space broken into its linear and angular parts.
    Vector3  linear
    Vector3  angular
    
    ================================================================================
    MSG: geometry_msgs/Vector3
    # This represents a vector in free space. 
    # It is only meant to represent a direction. Therefore, it does not
    # make sense to apply a translation to it (e.g., when applying a 
    # generic rigid transformation to a Vector3, tf2 will only apply the
    # rotation). If you want your data to be translatable too, use the
    # geometry_msgs/Point message instead.
    
    float64 x
    float64 y
    float64 z
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new CartesianTask(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.pose_actual !== undefined) {
      resolved.pose_actual = geometry_msgs.msg.Pose.Resolve(msg.pose_actual)
    }
    else {
      resolved.pose_actual = new geometry_msgs.msg.Pose()
    }

    if (msg.pose_reference !== undefined) {
      resolved.pose_reference = geometry_msgs.msg.Pose.Resolve(msg.pose_reference)
    }
    else {
      resolved.pose_reference = new geometry_msgs.msg.Pose()
    }

    if (msg.twist_actual !== undefined) {
      resolved.twist_actual = geometry_msgs.msg.Twist.Resolve(msg.twist_actual)
    }
    else {
      resolved.twist_actual = new geometry_msgs.msg.Twist()
    }

    if (msg.twist_reference !== undefined) {
      resolved.twist_reference = geometry_msgs.msg.Twist.Resolve(msg.twist_reference)
    }
    else {
      resolved.twist_reference = new geometry_msgs.msg.Twist()
    }

    return resolved;
    }
};

module.exports = CartesianTask;
