// Auto-generated. Do not edit!

// (in-package wb_controller.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let geometry_msgs = _finder('geometry_msgs');
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class ContactForces {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.name = null;
      this.contact = null;
      this.contact_positions = null;
      this.des_contact_forces = null;
      this.contact_forces = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('name')) {
        this.name = initObj.name
      }
      else {
        this.name = [];
      }
      if (initObj.hasOwnProperty('contact')) {
        this.contact = initObj.contact
      }
      else {
        this.contact = [];
      }
      if (initObj.hasOwnProperty('contact_positions')) {
        this.contact_positions = initObj.contact_positions
      }
      else {
        this.contact_positions = [];
      }
      if (initObj.hasOwnProperty('des_contact_forces')) {
        this.des_contact_forces = initObj.des_contact_forces
      }
      else {
        this.des_contact_forces = [];
      }
      if (initObj.hasOwnProperty('contact_forces')) {
        this.contact_forces = initObj.contact_forces
      }
      else {
        this.contact_forces = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type ContactForces
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [name]
    bufferOffset = _arraySerializer.string(obj.name, buffer, bufferOffset, null);
    // Serialize message field [contact]
    bufferOffset = _arraySerializer.bool(obj.contact, buffer, bufferOffset, null);
    // Serialize message field [contact_positions]
    // Serialize the length for message field [contact_positions]
    bufferOffset = _serializer.uint32(obj.contact_positions.length, buffer, bufferOffset);
    obj.contact_positions.forEach((val) => {
      bufferOffset = geometry_msgs.msg.Vector3.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [des_contact_forces]
    // Serialize the length for message field [des_contact_forces]
    bufferOffset = _serializer.uint32(obj.des_contact_forces.length, buffer, bufferOffset);
    obj.des_contact_forces.forEach((val) => {
      bufferOffset = geometry_msgs.msg.Wrench.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [contact_forces]
    // Serialize the length for message field [contact_forces]
    bufferOffset = _serializer.uint32(obj.contact_forces.length, buffer, bufferOffset);
    obj.contact_forces.forEach((val) => {
      bufferOffset = geometry_msgs.msg.Wrench.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type ContactForces
    let len;
    let data = new ContactForces(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [name]
    data.name = _arrayDeserializer.string(buffer, bufferOffset, null)
    // Deserialize message field [contact]
    data.contact = _arrayDeserializer.bool(buffer, bufferOffset, null)
    // Deserialize message field [contact_positions]
    // Deserialize array length for message field [contact_positions]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.contact_positions = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.contact_positions[i] = geometry_msgs.msg.Vector3.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [des_contact_forces]
    // Deserialize array length for message field [des_contact_forces]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.des_contact_forces = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.des_contact_forces[i] = geometry_msgs.msg.Wrench.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [contact_forces]
    // Deserialize array length for message field [contact_forces]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.contact_forces = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.contact_forces[i] = geometry_msgs.msg.Wrench.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    object.name.forEach((val) => {
      length += 4 + val.length;
    });
    length += object.contact.length;
    length += 24 * object.contact_positions.length;
    length += 48 * object.des_contact_forces.length;
    length += 48 * object.contact_forces.length;
    return length + 20;
  }

  static datatype() {
    // Returns string type for a message object
    return 'wb_controller/ContactForces';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '5db5e08618b6fcf379a7d5a2bd699e8e';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    std_msgs/Header header
    string[] name
    bool[] contact
    geometry_msgs/Vector3[] contact_positions
    geometry_msgs/Wrench[] des_contact_forces
    geometry_msgs/Wrench[] contact_forces
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    string frame_id
    
    ================================================================================
    MSG: geometry_msgs/Vector3
    # This represents a vector in free space. 
    # It is only meant to represent a direction. Therefore, it does not
    # make sense to apply a translation to it (e.g., when applying a 
    # generic rigid transformation to a Vector3, tf2 will only apply the
    # rotation). If you want your data to be translatable too, use the
    # geometry_msgs/Point message instead.
    
    float64 x
    float64 y
    float64 z
    ================================================================================
    MSG: geometry_msgs/Wrench
    # This represents force in free space, separated into
    # its linear and angular parts.
    Vector3  force
    Vector3  torque
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new ContactForces(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.name !== undefined) {
      resolved.name = msg.name;
    }
    else {
      resolved.name = []
    }

    if (msg.contact !== undefined) {
      resolved.contact = msg.contact;
    }
    else {
      resolved.contact = []
    }

    if (msg.contact_positions !== undefined) {
      resolved.contact_positions = new Array(msg.contact_positions.length);
      for (let i = 0; i < resolved.contact_positions.length; ++i) {
        resolved.contact_positions[i] = geometry_msgs.msg.Vector3.Resolve(msg.contact_positions[i]);
      }
    }
    else {
      resolved.contact_positions = []
    }

    if (msg.des_contact_forces !== undefined) {
      resolved.des_contact_forces = new Array(msg.des_contact_forces.length);
      for (let i = 0; i < resolved.des_contact_forces.length; ++i) {
        resolved.des_contact_forces[i] = geometry_msgs.msg.Wrench.Resolve(msg.des_contact_forces[i]);
      }
    }
    else {
      resolved.des_contact_forces = []
    }

    if (msg.contact_forces !== undefined) {
      resolved.contact_forces = new Array(msg.contact_forces.length);
      for (let i = 0; i < resolved.contact_forces.length; ++i) {
        resolved.contact_forces[i] = geometry_msgs.msg.Wrench.Resolve(msg.contact_forces[i]);
      }
    }
    else {
      resolved.contact_forces = []
    }

    return resolved;
    }
};

module.exports = ContactForces;
