// Auto-generated. Do not edit!

// (in-package wb_controller.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class JointsTask {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.name = null;
      this.position_actual = null;
      this.position_reference = null;
      this.velocity_actual = null;
      this.velocity_reference = null;
      this.position_error = null;
      this.velocity_error = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('name')) {
        this.name = initObj.name
      }
      else {
        this.name = [];
      }
      if (initObj.hasOwnProperty('position_actual')) {
        this.position_actual = initObj.position_actual
      }
      else {
        this.position_actual = [];
      }
      if (initObj.hasOwnProperty('position_reference')) {
        this.position_reference = initObj.position_reference
      }
      else {
        this.position_reference = [];
      }
      if (initObj.hasOwnProperty('velocity_actual')) {
        this.velocity_actual = initObj.velocity_actual
      }
      else {
        this.velocity_actual = [];
      }
      if (initObj.hasOwnProperty('velocity_reference')) {
        this.velocity_reference = initObj.velocity_reference
      }
      else {
        this.velocity_reference = [];
      }
      if (initObj.hasOwnProperty('position_error')) {
        this.position_error = initObj.position_error
      }
      else {
        this.position_error = [];
      }
      if (initObj.hasOwnProperty('velocity_error')) {
        this.velocity_error = initObj.velocity_error
      }
      else {
        this.velocity_error = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type JointsTask
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [name]
    bufferOffset = _arraySerializer.string(obj.name, buffer, bufferOffset, null);
    // Serialize message field [position_actual]
    bufferOffset = _arraySerializer.float64(obj.position_actual, buffer, bufferOffset, null);
    // Serialize message field [position_reference]
    bufferOffset = _arraySerializer.float64(obj.position_reference, buffer, bufferOffset, null);
    // Serialize message field [velocity_actual]
    bufferOffset = _arraySerializer.float64(obj.velocity_actual, buffer, bufferOffset, null);
    // Serialize message field [velocity_reference]
    bufferOffset = _arraySerializer.float64(obj.velocity_reference, buffer, bufferOffset, null);
    // Serialize message field [position_error]
    bufferOffset = _arraySerializer.float64(obj.position_error, buffer, bufferOffset, null);
    // Serialize message field [velocity_error]
    bufferOffset = _arraySerializer.float64(obj.velocity_error, buffer, bufferOffset, null);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type JointsTask
    let len;
    let data = new JointsTask(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [name]
    data.name = _arrayDeserializer.string(buffer, bufferOffset, null)
    // Deserialize message field [position_actual]
    data.position_actual = _arrayDeserializer.float64(buffer, bufferOffset, null)
    // Deserialize message field [position_reference]
    data.position_reference = _arrayDeserializer.float64(buffer, bufferOffset, null)
    // Deserialize message field [velocity_actual]
    data.velocity_actual = _arrayDeserializer.float64(buffer, bufferOffset, null)
    // Deserialize message field [velocity_reference]
    data.velocity_reference = _arrayDeserializer.float64(buffer, bufferOffset, null)
    // Deserialize message field [position_error]
    data.position_error = _arrayDeserializer.float64(buffer, bufferOffset, null)
    // Deserialize message field [velocity_error]
    data.velocity_error = _arrayDeserializer.float64(buffer, bufferOffset, null)
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    object.name.forEach((val) => {
      length += 4 + val.length;
    });
    length += 8 * object.position_actual.length;
    length += 8 * object.position_reference.length;
    length += 8 * object.velocity_actual.length;
    length += 8 * object.velocity_reference.length;
    length += 8 * object.position_error.length;
    length += 8 * object.velocity_error.length;
    return length + 28;
  }

  static datatype() {
    // Returns string type for a message object
    return 'wb_controller/JointsTask';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '3e490f07aa74f3673548e5a9cadd4db7';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    std_msgs/Header header
    string[] name
    float64[] position_actual
    float64[] position_reference
    float64[] velocity_actual
    float64[] velocity_reference
    float64[] position_error
    float64[] velocity_error
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    string frame_id
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new JointsTask(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.name !== undefined) {
      resolved.name = msg.name;
    }
    else {
      resolved.name = []
    }

    if (msg.position_actual !== undefined) {
      resolved.position_actual = msg.position_actual;
    }
    else {
      resolved.position_actual = []
    }

    if (msg.position_reference !== undefined) {
      resolved.position_reference = msg.position_reference;
    }
    else {
      resolved.position_reference = []
    }

    if (msg.velocity_actual !== undefined) {
      resolved.velocity_actual = msg.velocity_actual;
    }
    else {
      resolved.velocity_actual = []
    }

    if (msg.velocity_reference !== undefined) {
      resolved.velocity_reference = msg.velocity_reference;
    }
    else {
      resolved.velocity_reference = []
    }

    if (msg.position_error !== undefined) {
      resolved.position_error = msg.position_error;
    }
    else {
      resolved.position_error = []
    }

    if (msg.velocity_error !== undefined) {
      resolved.velocity_error = msg.velocity_error;
    }
    else {
      resolved.velocity_error = []
    }

    return resolved;
    }
};

module.exports = JointsTask;
