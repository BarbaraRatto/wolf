set(wb_controller_MESSAGE_FILES "msg/CartesianTask.msg;msg/JointsTask.msg;msg/ContactForces.msg")
set(wb_controller_SERVICE_FILES "")
