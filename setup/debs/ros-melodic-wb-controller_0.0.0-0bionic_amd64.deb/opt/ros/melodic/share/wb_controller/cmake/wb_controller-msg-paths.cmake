# generated from genmsg/cmake/pkg-msg-paths.cmake.installspace.in

_prepend_path("${wb_controller_DIR}/.." "msg" wb_controller_MSG_INCLUDE_DIRS UNIQUE)
set(wb_controller_MSG_DEPENDENCIES geometry_msgs)
